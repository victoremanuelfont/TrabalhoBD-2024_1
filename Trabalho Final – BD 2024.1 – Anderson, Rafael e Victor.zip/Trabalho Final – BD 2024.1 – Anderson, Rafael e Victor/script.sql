CREATE DATABASE Equipe509539;
USE Equipe509539;

-- Criação da Tabela departamento
-- Modificações: Não utilizar AUTO_INCREMENT no codigo para evitar conflitos com IDS duplicados.
-- Além disso, o incremento manual facilitaria o controle sobre os valores, tem maior flexibilidade nesse caso. 
CREATE TABLE departamento (
codigo INT PRIMARY KEY,
nome VARCHAR (50) NOT NULL
);

-- Criação da Tabela curso
-- Modificações: Foi necessário a criação da tabela curso para que houvesse uma relação mais clara entre cursos e disciplinas,
-- pois permitiu uma maior precisão ao associar disciplinas e alunos a um curso. 
-- Anteriormente, a relação entre departamento e curso era direta. 
-- Relacionamentos UM-PARA-MUITOS: Um departamento pode ter vários cursos associados a ele, 
-- mas cada curso está vinculado a apenas um departamento.
CREATE TABLE curso (
codigo INT PRIMARY KEY,
nome VARCHAR (50) NOT NULL,
id_departamento INT, 
FOREIGN KEY (id_departamento) REFERENCES departamento(codigo)
);

-- Criação da tabela disciplina
-- Modificações: Foi adcionado o campo categoria, para indicar se a disciplina é Obrigatoria ou optativa. 
-- Uso do tipo ENUM: Garante que apenas essas duas opções sejam válidas, pois esse tipo só aceita os valores pre-definidos.
-- Ou seja, o ENUM força a integridade dos dados ao restringir os valores de uma coluna, isso evita que valores inesperados sejam inseridos. 
-- Outro ponto interessante é o campo id_curso: que relaciona a disciplina com um curso específico. 
-- Além do campo id_curso, há também um relacionamento por meio do departamento, atraves do id_departamento. 
-- Relacionamento entre curso e disciplina: UM-PARA-MUITOS.
-- Um curso pode ter várias disciplinas associadas a ele, mas cada disciplina pertence a apenas um curso específico. 
-- Relacionamento Departamento e Disciplina: UM-PARA-MUITOS. 
-- Um departamento pode oferecer várias disciplinas, mas uma disciplina pertence a apenas um departamento. 
CREATE TABLE disciplina (
codigo INT PRIMARY KEY,
nome VARCHAR(50) NOT NULL,
ementa TEXT,
creditos INT,
categoria ENUM('OBRIGATORIA', 'OPTATIVA') NOT NULL,
id_curso INT,
id_departamento INT,
FOREIGN KEY (id_curso) REFERENCES curso(codigo),
FOREIGN KEY (id_departamento) REFERENCES departamento(codigo)
);

-- criação da tabela orientador
-- A associação a um departamento garante que cada orientador esteja vinculado a um departamento existente. 
-- Relacionamento UM-PARA-MUITOS: Um departamento pode ter vários orientadores, mas cada orientador pertence a um único departamento.
CREATE TABLE orientador (
numero INT PRIMARY KEY,
nome VARCHAR(50) NOT NULL,
id_departamento INT, 
FOREIGN KEY (id_departamento) REFERENCES departamento(codigo)
);

-- criação da tabela aluno
-- Modificações: A interação entre aluno e curso, através da chave estrangeira. 
-- Relacionamento UM-PARA-MUITOS
-- Um curso pode ter vários alunos matriculados, mas cada aluno está associado a penas um curso. 
CREATE TABLE aluno (
matricula INT PRIMARY KEY,
nome VARCHAR(50) NOT NULL,
endereco VARCHAR(255),
categoria ENUM('GRADUCAO', 'POSGRADUACAO') NOT NULL,
id_curso INT,
FOREIGN KEY (id_curso) REFERENCES curso(codigo)
);
-- Havia um erro na tabela anterior e foi necessário uma modificação.
ALTER TABLE aluno MODIFY categoria ENUM('graduacao','pos-graduacao'); 

-- criação de tabela do aluno da graduação
-- Uma diferença importante em relação a tabela anterior é que a tabela graduação é mais generica. 
-- Enquanto 'graduando' se refere ao aluno que está cursando a graduação, 
-- essa tabela pode ser interpretado de maneira mais ampla. 
-- Relacionamento UM-PARA-UM: Pois cada aluno está registrado apenas uma ves na tabela graduacao.
CREATE TABLE graduacao(
matricula INT PRIMARY KEY,
ano_de_ingresso INT,
FOREIGN KEY (matricula) REFERENCES aluno(matricula) 
);

-- criação da tabela de aluno da pós graduação
-- Modificações: Foi necessário construir um relacionamento com o orientador.
-- Relacionamento entre aluno e posgraduacao: UM-PARA-UM: Cada aluno está registrado apenas uma vez na tabela pos-graduacao.
-- Relacionamento entre aluno e orientador: UM-PARA-MUITOS: Um orientador pode ter vários alunos de pós-graduacao sob sua orientação, 
-- mas cada aluno de pós-graduacao está associado a apenas um orientador.
CREATE TABLE posgraduacao(
matricula INT PRIMARY KEY,
formacao TEXT,
id_orientador INT,
id_curso INT,
FOREIGN KEY (matricula) REFERENCES aluno(matricula),
FOREIGN KEY (id_orientador) REFERENCES orientador(numero),
FOREIGN KEY (id_curso) REFERENCES curso(codigo)
);

-- tabela telefones 
-- Relacionamento UM-PARA-MUITOS: Um aluno pode ter vários números mas cada número está associado a apenas um aluno.
CREATE TABLE telefone(
matricula INT,
numero VARCHAR(20),
descricao TEXT,
PRIMARY KEY (matricula, numero),
FOREIGN KEY (matricula) REFERENCES aluno(matricula)
);

-- tabela para o relacionamento entre aluno e disciplina
-- Relacionamento MUITOS-PARA-MUITOS: Um aluno pode se matricular em várias disciplinas, e cada disciplina pode ter vários alunos matriculados. 
CREATE TABLE aluno_disciplina(
matricula INT,
id_disciplina INT,
media DECIMAL(5,3),
frequencia INT,
PRIMARY KEY (matricula, id_disciplina),
FOREIGN KEY (matricula) REFERENCES aluno(matricula),
FOREIGN KEY (id_disciplina) References disciplina(codigo)
);

-- tabela para relacionamento do pre requisito
-- Relacionamento: Uma disciplina pode ter uma ou mais disciplinas como pré-requisitos
-- E uma disciplina pode ser pré-requisito para várias outras disciplinas. 
-- Existe uma relação muitos para muitos.
-- Implementação: criação da tabela pre_requisito, com chaves estrangeiras para disciplina e seu pré-requisito.
CREATE TABLE pre_requisito (
id_disciplina INT,
id_pre_requisito INT,
PRIMARY KEY (id_disciplina, id_pre_requisito),
FOREIGN KEY (id_disciplina) References disciplina(codigo),
FOREIGN KEY (id_pre_requisito) References disciplina(codigo)
); 

-- tabela para relacionamento do orientador ministrando disciplina
-- "Orientador ministra disciplina"
-- Relacionamento é de MUITOS-PARA-MUITOS
-- orientador_disciplina é uma tabela intermediária.
-- Um orientador pode ministrar várias disciplinas, e uma disciplina pode ser ministrada por vários orientadores. 
CREATE TABLE orientador_disciplina (
id_orientador INT,
id_disciplina INT,
PRIMARY KEY (id_orientador, id_disciplina),
FOREIGN KEY (id_orientador) REFERENCES orientador (numero),
FOREIGN KEY (id_disciplina) REFERENCES disciplina (codigo)
);






