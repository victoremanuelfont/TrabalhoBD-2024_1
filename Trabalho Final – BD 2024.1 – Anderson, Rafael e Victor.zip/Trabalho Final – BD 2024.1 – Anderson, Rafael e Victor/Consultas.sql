USE Equipe509539;

-- 1. Dado o número (matrícula) do aluno, deseja-se saber: 
-- 1.1. em quais disciplinas está atualmente matriculado 
-- Explicações sobre a consulta (1.1): 
-- A consulta é feita na tabela 'aluno_disciplina', onde está o relacionamento entre alunos e disciplinas que eles estão matriculados.
-- INNER JOIN que conecta as tabelas (aluno_disciplina e disciplina).
-- A condição de junção é baseada na igualdade entre o id_disciplina da tabela aluno_disciplina e codigo da tabela disciplina
-- A cláusula WHERE filtra os resultados para que seja considerado apenas os registros da tabela_disciplina.
-- A segunda condição da cláusula WHERE é 'ad.media IS NULL', que significa que a média final da disciplina da matricula digitada ainda não foi atribuída. 
SELECT d.nome 
FROM aluno_disciplina ad 
JOIN disciplina d 
ON ad.id_disciplina = d.codigo 
WHERE ad.matricula = 1 AND ad.media IS NULL;  -- Em 'ad.matricula = 1 ' no lugar do 1, pode-se digitar qualquer número de matricula. 

-- 1.2 Quais disciplinas já concluiu (media não nula):
-- A explicação do item 1.1 equivale para esta, com exceção da cláusula de Where. 
-- A cláusula WHERE em que 'ad.media IS NOT NULL' significa que a consulta irá retornar apenas para as disciplinas do aluno que tem uma média registrada. 
SELECT d.nome 
FROM aluno_disciplina ad
JOIN disciplina d 
ON ad.id_disciplina = d.codigo
WHERE ad.matricula = 2 AND ad.media IS NOT NULL; -- -- Em 'ad.matricula = 2 ' no lugar do 2, pode-se digitar qualquer número de matricula.

-- 1.3 Qual o curso deste aluno:
-- Explicações sobre a consulta (1.3): 
-- A consulta inicia na tabela aluno pois contém informações desejadas.
-- O INNER JOIN conecta as tabelas aluno e curso.
-- E a condição de junção é a igualdade entre o id da tabela aluno e codigo da tabela curso.
SELECT c.nome 
FROM aluno a
JOIN curso c 
ON a.id_curso = c.codigo
WHERE a.matricula = 2; -- No lugar do valor 2, pode-se digitar o numero de matricula de qualquer aluno cadastrado.

-- 1.4 Dados pessoais sobre o aluno:
SELECT a.nome, a.endereco, a.categoria 
FROM aluno a
WHERE a.matricula = 43;-- No lugar do valor 43, pode-se digitar o numero de matricula de qualquer aluno cadastrado.

-- 2. Dado o código de um departamento:
-- 2.1 Cursos que estão sob a responsabilidade do departamento:
-- Explicações sobre a consulta (2.1):
-- A consulta é feita na tabela curso, e a clausula WHERE filtra os resultados para incluir somente os cursos associados ao departamento digitado. 
SELECT c.nome 
FROM curso c
WHERE c.id_departamento = 2; -- No lugar do valor 2, pode-se digitar o numero de departamento de qualquer departamento cadastrado.

-- 2.2 Detalhes sobre o departamento:
SELECT *  -- Mostra tudo presente na tabela departamento
FROM departamento 
WHERE codigo = 2;

-- 3. Dado um curso, deseja-se saber: 
-- 3.1. disciplinas obrigatórias do curso:
-- Explicações sobre a consulta (3.1 e 3.2):
-- Seleciona o nome das disciplinas da tabela disciplina.
-- A cláusula WHERE filtra os resultados para considerar apenas as disciplinas que estão associadas ao curso com código digitado.
-- O campo id_curso relaciona a disciplina ao curso específico.
-- Filtra as disciplinas para garantir que apenas aquelas que são obrigatórias sejam retornadas.
-- O campo categoria indica se a disciplina é obrigatória ou optativa.
SELECT d.nome 
FROM disciplina d
WHERE d.id_curso = 2 AND d.categoria = 'OBRIGATORIA';

-- 3.2 Disciplinas optativas do curso:
SELECT d.nome 
FROM disciplina d
WHERE d.id_curso = 5 AND d.categoria = 'OPTATIVA';

-- 3.3 Alunos desse curso:
SELECT a.nome 
FROM aluno a
WHERE a.id_curso = 5;

-- 3.4 Alunos desse curso que já fizeram todas as disciplinas obrigatórias:
-- Explicações sobre a consulta (3.4):
-- Uso do Join: Faz a junção da tabela aluno com curso, para selecionar os alunos de um curso específico.
-- Em seguida, seleciona as disciplinas obrigatórias associadas ao curso.
-- O Uso do LEFT JOIN faz a junção com aluno_disciplina para verificar quais disciplinas os alunos concluíram, 
-- comparando a matrícula com o codigo da disciplina.
-- A cláusula WHERE seleciona os alunos de um curso específico
-- E o Group by agrupa os resultados por aluno.
-- O having verifica se o número de disciplinas obrigatórias é igual ao número de disciplinas que o aluno concluiu e se todas as médias das disciplinas estão preencidas.
SELECT a.nome
FROM aluno a
JOIN curso c
ON a.id_curso = c.codigo
JOIN disciplina d 
ON d.id_curso = c.codigo AND d.categoria = 'OBRIGATORIA'
LEFT JOIN aluno_disciplina ad 
ON ad.matricula = a.matricula AND ad.id_disciplina = d.codigo
WHERE a.id_curso = 1 -- Substitua pelo código do curso desejado
GROUP BY a.matricula
HAVING COUNT(DISTINCT d.codigo) = COUNT(DISTINCT ad.id_disciplina) AND COUNT(ad.media) = COUNT(DISTINCT d.codigo);

-- 3.5 Alunos desse curso que não fizeram nenhuma disciplina optativa:
-- Explicações sobre a consulta (3.5):
-- A explicação da consulta 3.4 se aplica em partes a consulta 3.5
-- O having retorna apenas os alunos que não tem disciplinas optativas no histórico.
SELECT a.nome
FROM aluno a
LEFT JOIN aluno_disciplina ad 
ON a.matricula = ad.matricula
LEFT JOIN disciplina d 
ON ad.id_disciplina = d.codigo AND d.categoria = 'OPTATIVA'
WHERE a.id_curso = 5 -- Substitua pelo código do curso desejado
GROUP BY a.matricula
HAVING COUNT(d.codigo) = 0;

-- 4. Dado uma disciplina, deseja-se saber:
-- 4.1. alunos matriculados na disciplina 
-- Faz uma junção entre a tabela aluno e a tabela aluno_disciplina, que contém os registros de quais disciplinas os alunos estão cursando. 
-- A junção é baseada na coluna matricula, que é a chave primária da tabela aluno e uma chave estrangeira na tabela aluno_disciplina.
-- O uso do Where filtra os resultados para incluir apenas os alunos que estão matriculados na disciplina com o código digitado. 
SELECT a.nome 
FROM aluno a
JOIN aluno_disciplina ad 
ON a.matricula = ad.matricula
WHERE ad.id_disciplina = 5; -- Substitua pelo código da disciplina desejada

-- 4.2 Pré-requisitos da disciplina:
-- Explicações sobre a consulta (4.2):
-- mostra a disciplina digitando o id
-- É selecionado o nome da disciplina e o nome do pré-requisito.
-- A condição filtra a consulta para que ela retorne apenas as informações sobre a disciplina com o id informado pelo usuário. 
SELECT d.nome AS disciplina, d_pre.nome AS pre_requisito
FROM pre_requisito pr
JOIN disciplina d 
ON pr.id_disciplina = d.codigo
JOIN disciplina d_pre 
ON pr.id_pre_requisito = d_pre.codigo
WHERE d.codigo = 4; 

-- 4.3 Disciplinas para as quais a mesma é pré-requisito:
-- Explicações sobre a consulta (4.3):
-- Seleciona o nome das disciplinas que têm a disciplina dada como pré-requisito.
-- Nome da disciplina que é o pré-requisito (informado pelo usuário).
-- Utiliza a tabela pre_requisito, que define as relações de pré-requisitos entre disciplinas.
-- Junta a tabela pre_requisito com a tabela disciplina para obter os nomes das disciplinas que dependem de um pré-requisito.
-- Faz a junção da tabela pre_requisito com a tabela disciplina novamente para obter o nome da disciplina que é o pré-requisito.
-- O campo d_pre.codigo é usado para filtrar pelo ID da disciplina fornecida pelo usuário, que está servindo como pré-requisito.
SELECT d.nome AS disciplina, d_pre.nome AS pre_requisito
FROM pre_requisito pr
JOIN disciplina d 
ON pr.id_disciplina = d.codigo
JOIN disciplina d_pre 
ON pr.id_pre_requisito = d_pre.codigo
WHERE d_pre.codigo = 2;  

-- 5. Dado um orientador, deseja-se saber: 
-- 5.1. alunos orientandos daquele orientador
-- Explicações sobre a consulta (5.1):
-- A consulta começa a partir da tabela aluno, que contém as informações dos alunos.
-- Faz uma junção com a tabela posgraduacao, que contém os registros dos alunos de pós-graduação, vinculando cada aluno ao seu orientador. 
-- A junção é feita pelo campo matricula (identificação do aluno).
-- Faz uma junção com a tabela orientador para obter o nome do orientador associado ao aluno.
--  junção ocorre pelo campo id_orientador na tabela posgraduacao e o campo numero na tabela orientador.
-- A cláusula WHERE filtra os resultados para selecionar apenas os alunos orientados pelo orientador de ID 
SELECT a.nome AS aluno, o.nome AS orientador
FROM aluno a
JOIN posgraduacao p 
ON a.matricula = p.matricula
JOIN orientador o 
ON p.id_orientador = o.numero
WHERE o.numero = 1;  -- Substitua 1 pelo número do orientador desejado.

-- 5.2 Disciplinas dadas pelo orientador:
-- Explicações sobre a consulta (5.2):
-- A consulta começa a partir da tabela disciplina, que contém informações sobre as disciplinas.
-- Faz uma junção com a tabela orientador_disciplina, que relaciona os orientadores às disciplinas que eles ministram.
-- Faz uma junção com a tabela orientador para obter o nome do orientador que ministra a disciplina. 
-- A cláusula WHERE filtra os resultados para selecionar as disciplinas ministradas pelo orientador de ID.
SELECT d.nome AS disciplina, o.nome AS orientador
FROM disciplina d
JOIN orientador_disciplina od 
ON d.codigo = od.id_disciplina
JOIN orientador o 
ON od.id_orientador = o.numero
WHERE o.numero = 1; -- Substitua 1 pelo número do orientador desejado.


-- 5.3. total de créditos das disciplinas do mesmo
-- Explicações sobre a consulta (5.3):
-- SUM(d.creditos): Calcula a soma dos créditos das disciplinas ministradas pelo orientador, retornando o total de créditos como total_creditos.
-- A consulta começa a partir da tabela disciplina, que contém informações sobre as disciplinas, incluindo o número de créditos de cada uma.
-- Junta a tabela disciplina com orientador_disciplina, associando as disciplinas aos orientadores.
-- Junta a tabela orientador_disciplina com a tabela orientador, permitindo que você obtenha o nome do orientador.
-- Filtra os resultados para considerar apenas as disciplinas ministradas pelo orientador com ID
-- Agrupa os resultados pelo nome do orientador para garantir que o total de créditos seja calculado para cada orientador individualmente.
SELECT o.nome AS orientador, SUM(d.creditos) AS total_creditos
FROM disciplina d
JOIN orientador_disciplina od 
ON d.codigo = od.id_disciplina
JOIN orientador o 
ON od.id_orientador = o.numero
WHERE o.numero = 1  -- Substitua 1 pelo número do orientador desejado.
GROUP BY o.nome;










