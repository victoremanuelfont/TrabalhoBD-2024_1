USE Equipe509539;
-- Inserindo os dados na tabela departamento.
INSERT INTO departamento(codigo, nome) VALUES
(1,'Departamento de Ciências Economicas'), (2,'Departamento de Engenharia da Computação'), (3,'Departamento de Engenharia Elétrica'),
(4,'Departamento de Finanças'), (5,'Departamento de Medicina'), (6,'Departamento de Música'), 
(7,'Departamento de Odontologia'), (8,'Departamento de Psicologia');

-- Inserindo os dados na tabela curso, que é associado a um departamento.
INSERT INTO curso (codigo, nome, id_departamento) VALUES
(1,'Ciências Economicas',1), (2,'Engenharia da Computação',2), 
(3,'Engenharia Elétrica',3), (4,'Finanças',4), (5,'Medicina',5), 
(6,'Música – Licenciatura',6), (7,'Odontologia',7), (8,'Psicologia',8);

-- Inserindo os dados na tabela disciplina, que tem um curso e um departamento. 
-- Foi inserido as disciplinas do curso de id =1 (Ciencias Economicas), e de departamento de id= 1 (Departamento de Ciencias Economicas)
INSERT INTO disciplina (codigo, nome, ementa, creditos, categoria, id_curso, id_departamento) VALUES
(1,'INTRODUÇÃO A ECONOMIA', 'Conceitos e princípios básicos da economia.', 4,'OBRIGATORIA',1,1),
(2,'ECONOMIA E CONTABILIDADE', 'Conceitos e princípios da economia como ciência humana.', 4,'OBRIGATORIA', 1,1),
(3,'METODOLOGIA DO TRABALHO CIENTÍFICO', 'Fundamentos de macroeconomia.', 4, 'OBRIGATORIA', 1,1),
(4,'ECONOMIA MATEMÁTICA','Conceitos e princípios do PIB real, PIB nominal e do deflator implícito do PIB.', 4, 'OPTATIVA', 1,1),
(5,'ESTATÍSTICA ECONÔMICA','Fundamentos de Agregados macroeconômicos e identidades macroeconômicas.', 4,'OPTATIVA', 1,1);

-- Inserindo as disciplinas do curso de id=2 (Engenharia de Computação) e de departamento de id=2 (Departamento de Engenharia de computação)
INSERT INTO disciplina (codigo, nome, ementa, creditos, categoria, id_curso, id_departamento) VALUES
(6,'INTRODUÇÃO A ENGENHARIA', 'Esta disciplina tem o intuito de esclarecer ao aluno do primeiro semestre do Curso de
Engenharia da Computação.', 4,'OPTATIVA',2, 2),
(7,'MATEMÁTICA DISCRETA PARA COMPUTAÇÃO', 'A matemática discreta é útil, especialmente para os estudantes cujo interesse está
centrado na ciência da computação e engenharia.', 4,'OBRIGATORIA', 2,2),
(8,'CÁLCULO DIFERENCIAL E INTEGRAL', 'Cálculo Diferencial e Integral I fornece os tópicos matemáticos
preliminares.', 4,'OBRIGATORIA', 2 , 2),
(9,'FÍSICA GERAL', 'Compreender os princípios
fundamentais a serem aplicados no desenvolvimento de processos tecnológicos.',4,'OPTATIVA', 2,2),
(10,'PROGRAMAÇÃO COMPUTACIONAL', 'Introdução à computação; sistemas de numeração; introdução aos algoritmos; tipos básicos de
dados; estruturas de controle; operadores.', 6 ,'OBRIGATORIA', 2,2);

-- Inserindo as disciplinas do curso de id=3 (Engenharia Elétrica) do departamento de Engenharia Elétrica de id=3
INSERT INTO disciplina (codigo, nome, ementa, creditos, categoria, id_curso, id_departamento) VALUES
(11,'INTRODUÇÃO A ENGENHARIA ELÉTRICA', 'A importância da comunicação e expressão técnica (oral e escrita).',4,'OBRIGATORIA',3,3 ),
(12,'CÁLCULO DIFERENCIAL E INTEGRAL I', 'A disciplina Cálculo Diferencial e Integral I fornece os tópicos matemáticos
preliminares.',4,'OBRIGATORIA',3,3 ),
(13,'FÍSICA GERAL I', 'Compreender os princípios
fundamentais a serem aplicados no desenvolvimento de processos tecnológicos.',4,'OBRIGATORIA',3,3 ),
(14,'PROGRAMAÇÃO','Introdução à computação; sistemas de numeração; introdução aos algoritmos; tipos básicos de
dados; estruturas de controle; operadores.', 4,'OPTATIVA', 3,3),
(15,'QUIMICA GERAL', 'Explicar e aplicar conceitos, princípios e leis fundamentais referentes à estrutura e aos estados físicos da matéria.', 4,'OPTATIVA',3,3 );

-- Inserindo as disciplinas do curso de id=4 (Curso de Finanças) do departamento de id=4 (Departamento de Finanças)
INSERT INTO disciplina (codigo, nome, ementa, creditos, categoria, id_curso, id_departamento) VALUES
(16,'INTRODUÇÃO A ECONOMIA', 'Conceitos e princípios básicos da economia: economia como ciência humana; problemas econômicos fundamentais.',4 ,'OBRIGATORIA', 4,4),
(17,'ECONOMIA E CONTABILIDADE','Modelos como simplificação da realidade e modelos aplicados a simplificação da realidade econômica.',4 ,'OBRIGATORIA',4,4),
(18,'METODOLOGIA DO TRABALHO CIENTÍFICO','Fundamentos de microeconomia: trade-off e custo de oportunidade.',4 ,'OBRIGATORIA',4,4),
(19,'ECONOMIA MATEMÁTICA','Teoria da produção, teoria do custo e as diferentes estruturas de mercado.',4 ,'OPTATIVA',4,4),
(20,'ESTATISTICA ECONOMICA', 'Fundamentos de macroeconomia: agregados macroeconômicos e identidades macroeconômicas.',4 ,'OPTATIVA',4,4);

-- Inserindo as disciplinas do curso de id=5 (Curso de Medicina) do departamento de Medicina
INSERT INTO disciplina (codigo, nome, ementa, creditos, categoria, id_curso, id_departamento) VALUES
(21,'EDUCAÇÃO E MEDICINA','Acolhimento e integração dos novos discentes à escola médica.',2,'OPTATIVA',5,5),
(22,'GÊNESE E DESENVOLVIMENTO','Gametogênese e fertilização humana. Implantação e desenvolvimento do ovo.',4,'OBRIGATORIA',5,5),
(23,'SISTEMA DIGESTÓRIO','Embriogênese do tubo digestivo. Histologia dos componentes do sistema digestório.',8,'OBRIGATORIA',5,5),
(24,'APARELHO LOCOMOTOR','	Embriologia do sistema esquelético, muscular e articular.',6,'OBRIGATORIA',5,5),
(25,'BIOLOGIA CELULAR, MOLECULAR E FARMACOLOGIA','Moléculas da vida e reações enzimáticas. Estrutura celular: principais componentes e organelas.',8,'OPTATIVA',5,5),
(26,'INVESTIGAÇÃO E PROJETOS EM SAÚDE COLETIVA','Processo Saúde-Doença. Epidemiologia Descritiva.',4,'OBRIGATORIA',5,5),
(27,'INTRODUÇÃO A MEDICINA','Processo educacional na universidade como formação pessoal, científica, profissional e política.',2,'OPTATIVA',5,5);

-- Inserindo os dados do curso de musica
INSERT INTO disciplina (codigo, nome, ementa, creditos, categoria, id_curso, id_departamento) VALUES
(28,'LEITURA DE PARTITURAS','As partituras registram ideias harmônicas, rítmicas e melódicas.',4,'OBRIGATORIA',2,6),
(29,'ESTRUTURAÇÃO MUSICAL','Cada linha e cada espaço são usados para representar uma nota musical diferente.',4, 'OBRIGATORIA',2,6),
(30,'OFICINA DE MÚSICA','Atividades que envolvem a exploração do som e o desenvolvimento da sensibilidade musical.',2,'OPTATIVA',2,6);

-- Inserindo os dados de Odontologia
INSERT INTO disciplina (codigo, nome, ementa, creditos, categoria, id_curso, id_departamento) VALUES
(31,'INTRODUÇÃO A ODONTOLOGIA','Conceitos e princípios do ser humano na dimensão biopsicossocial.',4,'OBRIGATORIA',7,7),
(32,'SOCIOLOGIA DA SAÚDE','Contexto e surgimento da sociologia. Formas de conhecimento e representação do mundo.',4,'OBRIGATORIA',7,7),
(33,'BIOCIÊNCIA','Conceitos e princípios da Biologia Celular e Bioquímica: Vias Metabólicas; Água e Biomoléculas.',4,'OBRIGATORIA',7,7),
(34,'FORMAÇÃO DO CORPO HUMANO','Conceitos e princípios da Embriologia, Histologia e Anatomias Humanas.',6,'OPTATIVA',7,7),
(35,'IMUNOLOGIA GERAL','Conceitos e princípios da Biologia da Resposta Imune, Organização do sistema imune e diferenciação das células de defesa.',4,'OPTATIVA',7,7);

-- Inserindo os dados do curso de Psicologia
INSERT INTO disciplina (codigo, nome, ementa, creditos, categoria, id_curso, id_departamento) VALUES
(36,'INTRODUÇÃO A FILOSOFIA','É fundamental para a preparação dos discentes recém-ingressos na universidade, vez que possibilita o desenvolvimento da criticidade e a reflexão rigorosa acerca da realidade.',4,'OBRIGATORIA',8,8),
(37,'INTRODUÇÃO A SOCIOLOGIA','Apresentar as diferentes formas de apreensão e representação do mundo e as dimensões constituintes da sociedade humana.',4,'OBRIGATORIA',8,8),
(38,'SEMNINARIO DE INTEGRAÇÃO','Analisar a sociologia em seu surgimento e desenvolvimento, discutindo temas sociais contemporâneos.',4,'OBRIGATORIA',8,8),
(39,'INTRODUÇÃO A PSICOLOGIA','Analisar a sociedade como uma construção social entendendo os processos de subjetivação do indivíduo.',4,'OBRIGATORIA',8,8),
(40,'METODOLOGIA DO TRABALHO CIENTÍFICO','Compreender o conceito de Ideologia de acordo com Pedrinho Guareschi e a sua importância na compreensão da realidade social.',4,'OPTATIVA',8,8);

-- Foi necessário alterações: O comando atualiza o curso ao qual as disciplinas de código 28,29,30. A disciplinas com esses códigos serão associados ao cursp de codigo 6.
UPDATE disciplina SET id_curso = 6 WHERE codigo = 28;
UPDATE disciplina SET id_curso = 6 WHERE codigo = 29;
UPDATE disciplina SET id_curso = 6 WHERE codigo = 30;

-- Orientadores do departamento de Economia
INSERT INTO orientador (numero, nome, id_departamento) VALUES
(1,'Alfredo José Pessoa', 1),
(2,'Carlos Américo Leite',1),
(3,'Eveline Barbosa Silva',1),
(4,'Fábio Maia Sobral',1),
(5,'Inez Silvia Batista Castro',1);

-- Orientadores do departamento de Engenharia de computação
INSERT INTO orientador (numero, nome, id_departamento) VALUES
(6,'Fernando Rodrigues de Almeida',2),
(7,'Ialis Cvalcante de Paula',2),
(8,'Luis Eduardo Araripe',2),
(9,'Rui Facundo Vigelis',2),
(10,'Jarbas Joaci de Mesquita',2);

-- Orientadores do departamento de Engenharia de elétrica
INSERT INTO orientador (numero, nome, id_departamento) VALUES
(11,'Arthur Plínio de Souza',3),
(12,'Bismark Claure Torrico',3),
(13,'Carlos Gustavo Castelo Branco',3),
(14,'Dalton de Araújo Honorio',3),
(15,'Demercil de Souza Oliveira',3);

-- Orientadores do departamento de Finanças
INSERT INTO orientador (numero, nome, id_departamento) VALUES
(16,'Andrei Gomes Simonassi',4),
(17,'Christiano Modesto Penna',4),
(18,'Elano Ferreira Arruda',4),
(19,'Guilherme Diniz Irffi',4),
(20,'Pablo Urano de Carvalho',4);

-- Orientadores do departamento de Medicina
INSERT INTO orientador (numero, nome, id_departamento) VALUES
(21,'Ana Angélicas Lustosa B. Araújo',5),
(22,'Anastácio de Queiroz de Sousa',5),
(23,'Carlos Ewerton Maia Rodrigues',5),
(24,'Eanes Delgado Barros Pereira',5),
(25,'Elnice Soares de Castro',5),
(26,'Elizabeth de Francesco Daher',5),
(27,'Francisco de Assis Aquino Gondim',5);

-- Orientadores do departamento de Música
INSERT INTO orientador (numero, nome, id_departamento) VALUES
(28,'Adeline Annelyse Marie Stervinou',6),
(29,'Eveline Andrade Ferreira',6),
(30,'Fernando Antonio Ferreira de Souza',6);

-- -- Orientadores do departamento de Odontologia
INSERT INTO orientador (numero, nome, id_departamento) VALUES
(31,'Adriana Kelly de Sousa Santiago Barbosa',7),
(32,'Beatriz Gonçalves Neves',7),
(33,'Bruno Carvalho de Sousa',7),
(34,'Celiane Mary Carneiro Tapety',7),
(35,'Denise Sá Maia Casselli',7);

-- Orientadores do departamento de Psicologia
INSERT INTO orientador (numero, nome, id_departamento) VALUES
(36,'Amanda Biasi Callegari',8),
(37,'Juliana Vieira Sampaio',8),
(38,'Luis Achilles Rodrigues Furtado',8),
(39,'Carlos Roger Sales da Ponte',8),
(40,'Natália Santos Marques',8);

-- Inserindo os alunos do curso de Economia
INSERT INTO aluno (matricula, nome, endereco, categoria, id_curso) VALUES
(1, 'Lucas Pereira', 'Rua A, 123', 'graduacao', 1),
(2, 'Ana Souza', 'Rua B, 456', 'graduacao', 1),
(3, 'Mariana Lima', 'Rua C, 789', 'graduacao', 1),
(4, 'Miguel Lucas', 'Rua D, 125', 'pos-graduacao',1),
(5, 'Juliana Meneguel', 'Rua E, 125', 'pos-graduacao',1);

-- Inserindo os alunos do curso de Computação
INSERT INTO aluno (matricula, nome, endereco, categoria, id_curso) VALUES
(6, 'João Carlos', 'Rua E, 102', 'pos-graduacao', 2),
(7, 'Fernanda Silva', 'Rua F, 103', 'pos-graduacao', 2),
(8, 'Carlos Santos', 'Rua G, 104', 'graduacao', 2),
(9, 'Patricia Ferreira', 'Rua H, 105', 'graduacao', 2),
(10, 'Deolane Brito', 'Alphavile', 'graduacao', 2);

-- -- Inserindo os alunos do curso de Elétrica 
INSERT INTO aluno (matricula, nome, endereco, categoria, id_curso) VALUES
(11, 'Rafael Oliveira', 'Rua K, 108', 'graduacao', 3),
(12, 'Sandra Lima', 'Rua L, 109', 'graduacao', 3),
(13, 'Bruno Martins', 'Rua M, 110', 'graduacao', 3),
(14, 'Camila Rodrigues', 'Rua N, 111', 'pos-graduacao', 3),
(15, 'Renato Souza', 'Rua O, 112', 'pos-graduacao', 3);

-- Inserindo os alunos do curso de Finanças
INSERT INTO aluno (matricula, nome, endereco, categoria, id_curso) VALUES
(16, 'Claudia Ferreira', 'Rua P, 113', 'pos-graduacao', 4),
(17, 'Igor Almeida', 'Rua Q, 114', 'pos-graduacao', 4),
(18, 'Paula Castro', 'Rua R, 115', 'pos-graduacao', 4),
(19, 'Gustavo Costa', 'Rua S, 116', 'graduacao', 4),
(20, 'Joao guilherme', 'Rua X, 14', 'graduacao', 4);

-- Inserindo os alunos do curso de Medicina
INSERT INTO aluno (matricula, nome, endereco, categoria, id_curso) VALUES
(21,'Thiago Mendes','Rua U, 118', 'graduacao', 5),
(22,'Isabel Moura','Rua V, 119', 'graduacao', 5),
(23,'Lucas Almeida','Rua W, 120','graduacao', 5),
(24,'Sofia Costa', 'Rua X, 121','graduacao', 5),
(25,'Mateus Rocha', 'Rua Y, 122','graduacao', 5),
(26, 'Júlia Andrade', 'Rua Z, 123','pos-graduacao', 5),
(27, 'Felipe Silva', 'Rua A1, 124', 'pos-graduacao', 5);

-- Inserindo os alunos do curso de Medicina e Música
INSERT INTO aluno (matricula, nome, endereco, categoria, id_curso) VALUES
(28,'Marcela Lima', 'Rua B1, 125','graduacao', 5),
(29,'Pedro Oliveira', 'Rua C1, 126','graduacao', 5),
(30, 'Fernanda Santos', 'Rua D1, 127', 'graduacao', 6);

-- Inserindo os alunos do curso de Música
INSERT INTO aluno (matricula, nome, endereco, categoria, id_curso) VALUES
(31, 'Fernando Santos', 'Rua D1, 127', 'pos-graduacao', 6),
(32, 'Manuel Santos', 'Rua D1, 127', 'pos-graduacao', 6);

-- Inserindo os alunos do curso de Odontologia
INSERT INTO aluno (matricula, nome, endereco, categoria, id_curso) VALUES
(33, 'Marcelo Souza', 'Rua G1, 130', 'graduacao', 7),
(34, 'Juliana Ferreira', 'Rua H1, 131', 'graduacao', 7),
(35, 'André Almeida', 'Rua I1, 132', 'graduacao', 7),
(36, 'Mariana Costa', 'Rua J1, 133', 'graduacao', 7),
(37, 'Mariano Costa', 'Rua J1, 133', 'pos-graduacao', 7);

-- Inserindo os alunos do curso de Psicologia 
INSERT INTO aluno (matricula, nome, endereco, categoria, id_curso) VALUES
(38, 'Beatriz Rodrigues', 'Rua L1, 135', 'graduacao', 8), 
(39, 'Rafael Lima', 'Rua M1, 136', 'graduacao', 8),       
(40, 'Clara Silva', 'Rua N1, 137', 'graduacao', 8),         
(41, 'João Moura', 'Rua O1, 138', 'graduacao', 8),         
(42, 'Ana Clara', 'Rua P1, 139', 'pos-graduacao', 8),           
(43, 'Bruno Martins', 'Rua Q1, 140', 'pos-graduacao', 8); 

INSERT INTO graduacao (matricula, ano_de_ingresso) VALUES
(1, 2020), (2, 2021), (3, 2020), (8, 2019), (9, 2022), 
(10, 2021), (11, 2019), (12, 2020), (13, 2022), (19, 2021), 
(20, 2018), (21, 2019), (22, 2020), (23, 2022), (24, 2021), 
(25, 2022), (28, 2020), (29, 2021), (30, 2022), (33, 2021), 
(34, 2020), (35, 2021), (36, 2019), (38, 2022), (39, 2020), 
(40, 2021), (41, 2022);

INSERT INTO posgraduacao (matricula, formacao, id_orientador, id_curso) VALUES
(4, 'Economista', 1, 1), (5, 'Economista', 2, 1), (6, 'Programador', 6, 2),
(7, 'Programador', 7, 2), (14, 'Engenheiro', 11, 3), (15, 'Engenheiro', 12, 3),
(16, 'Engenheiro', 13, 3), (17, 'Programador', 16, 4);

INSERT INTO posgraduacao (matricula, formacao, id_orientador, id_curso) VALUES
(18, 'Economista', 17, 4), (26, 'Clínico Geral', 21, 5),
(27, 'Enfermeiro', 22, 5),(31, 'DJ', 28, 6),
(32, 'Produtor Musical', 29, 6),(37, 'Dentista', 31, 7),
(42, 'Professor da Educação infantil', 36, 8),(43,'Educador', 37, 8);

INSERT INTO telefone (matricula, numero, descricao) VALUES
(1, '1111-1111', 'Residencial'), (2, '2222-2222', 'Celular'), (3, '3333-3333', 'Residencial'),
(4, '4444-4444', 'Celular'), (5, '5555-5555', 'Residencial'), (6, '6666-6666', 'Celular'),
(7, '7777-7777', 'Residencial'), (8, '8888-8888', 'Celular'), (9, '9999-9999', 'Residencial'),
(10, '1010-1010', 'Celular'), (11, '1111-1111', 'Residencial'), (12, '1212-1212', 'Celular'),
(13, '1313-1313', 'Residencial'), (14, '1414-1414', 'Celular'), (15, '1515-1515', 'Residencial'),
(16, '1616-1616', 'Celular'), (17, '1717-1717', 'Residencial'), (18, '1818-1818', 'Celular'),
(19, '1919-1919', 'Residencial'), (20, '2020-2020', 'Celular'), (21, '2121-2121', 'Residencial'),
(22, '2222-2222', 'Celular'), (23, '2323-2323', 'Residencial'), (24, '2424-2424', 'Celular'),
(25, '2525-2525', 'Residencial'), (26, '2626-2626', 'Celular'), (27, '2727-2727', 'Residencial'),
(28, '2828-2828', 'Celular'), (29, '2929-2929', 'Residencial'), (30, '3030-3030', 'Celular'),
(31, '3131-3131', 'Residencial'), (32, '3232-3232', 'Celular'), (33, '3333-3333', 'Residencial'),
(34, '3434-3434', 'Celular'), (35, '3535-3535', 'Residencial'), (36, '3636-3636', 'Celular'),
(37, '3737-3737', 'Residencial'), (38, '3838-3838', 'Celular'), (39, '3939-3939', 'Residencial'),
(40, '4040-4040', 'Celular'), (41, '4141-4141', 'Residencial'), (42, '4242-4242', 'Celular'),
(43, '4343-4343', 'Residencial');

INSERT INTO aluno_disciplina (matricula, id_disciplina, media, frequencia) VALUES
(1, 1, NULL, 16), (2, 2, 8.5, 15), (3, 3, NULL, 14), (4, 4, 7.8, 13),
(5, 5, 8.0, 12), (6, 6, NULL, 11), (7, 7, 7.6, 10), (8, 8, NULL, 15),
(9, 9, 6.9, 16), (10, 10, 8.3, 14), (11, 11, NULL, 13), (12, 12, 7.7, 12),
(13, 13, 8.2, 11), (14, 14, NULL, 10), (15, 15, 7.4, 16), (16, 16, 8.1, 15),
(17, 17, 9.3, 14), (18, 18, NULL, 13), (19, 19, 8.5, 12), (20, 20, NULL, 11),
(21, 21, 6.7, 16), (22, 22, 8.6, 15), (23, 23, NULL, 14), (24, 24, 9.2, 13),
(25, 25, 8.0, 12), (26, 26, NULL, 11), (27, 27, 7.5, 10), (28, 28, 8.3, 16),
(29, 29, 9.4, 15), (30, 30, NULL, 14), (31, 31, 8.2, 13), (32, 32, 7.6, 12),
(33, 33, NULL, 11), (34, 34, 9.2, 10), (35, 35, 7.4, 16), (36, 36, NULL, 15),
(37, 37, 9.0, 14), (38, 38, 7.7, 13), (39, 39, 8.4, 12), (40, 40, NULL, 11),
(41, 1, 6.9, 16), (42, 2, NULL, 15), (43, 3, 7.8, 14);


INSERT INTO pre_requisito (id_disciplina, id_pre_requisito) VALUES
(4, 2),(9, 8),(14, 12),(19, 16),(24, 25),(30, 29),(34, 33),(40, 39);

INSERT INTO orientador_disciplina (id_orientador, id_disciplina) VALUES
(1, 1), (2, 2), (3, 3), (4, 4), (5, 5), (6, 6), (7, 7), (8, 8), (9, 9), (10, 10),
(11, 11), (12, 12), (13, 13), (14, 14), (15, 15), (16, 16), (17, 17), (18, 18), (19, 19), (20, 20),
(21, 21), (22, 22), (23, 23), (24, 24), (25, 25), (26, 26), (27, 27), (28, 28), (29, 29), (30, 30),
(31, 31), (32, 32), (33, 33), (34, 34), (35, 35), (36, 36), (37, 37), (38, 38), (39, 39), (40, 40);

-- Inserindo dados para testar a consulta 3.4
INSERT INTO aluno_disciplina (matricula, id_disciplina, media, frequencia) VALUES
(2,1,8.5,5), (2,3,8.5,5), (2,4,8.5,5), (2,5,8.5,5);


INSERT INTO pre_requisito (id_disciplina, id_pre_requisito) VALUES
(5, 2), (6, 2);














